"""
图形界面模块
"""

from .tournament_gui import TournamentGUI

__all__ = ['TournamentGUI']

