"""
比赛管理图形界面
使用tkinter创建图形界面来选择和管理比赛
"""
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
from pathlib import Path
import sys

# 添加项目根目录到路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from utils.agent_loader import AgentLoader
from tournament.tournament import RoundRobinTournament, EliminationTournament
from tournament.group_tournament import GroupTournament


class TournamentGUI:
    """比赛管理图形界面"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("AI斗兽场 - 比赛管理系统")
        self.root.geometry("900x700")
        
        self.agents = []
        self.tournament_thread = None
        
        self._create_widgets()
        self._load_agents()
    
    def _create_widgets(self):
        """创建界面组件"""
        # 标题
        title_frame = tk.Frame(self.root)
        title_frame.pack(pady=10)
        tk.Label(title_frame, text="AI斗兽场 - 比赛管理系统", 
                font=("Arial", 16, "bold")).pack()
        
        # Agent列表区域
        agent_frame = tk.LabelFrame(self.root, text="参赛者列表", padx=10, pady=10)
        agent_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Agent列表
        list_frame = tk.Frame(agent_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.agent_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, 
                                        selectmode=tk.EXTENDED, height=10)
        self.agent_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.agent_listbox.yview)
        
        # 刷新按钮
        refresh_btn = tk.Button(agent_frame, text="刷新列表", command=self._load_agents)
        refresh_btn.pack(pady=5)
        
        # 比赛设置区域
        settings_frame = tk.LabelFrame(self.root, text="比赛设置", padx=10, pady=10)
        settings_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # 比赛模式选择
        mode_frame = tk.Frame(settings_frame)
        mode_frame.pack(fill=tk.X, pady=5)
        tk.Label(mode_frame, text="比赛模式:").pack(side=tk.LEFT, padx=5)
        
        self.mode_var = tk.StringVar(value="group")
        modes = [
            ("分组赛（适合大规模）", "group"),
            ("循环赛", "round_robin"),
            ("淘汰赛", "elimination"),
            ("循环赛（带回放）", "round_robin_replay")
        ]
        for text, value in modes:
            tk.Radiobutton(mode_frame, text=text, variable=self.mode_var, 
                          value=value).pack(side=tk.LEFT, padx=5)
        
        # 分组设置（仅分组赛显示）
        self.group_frame = tk.Frame(settings_frame)
        self.group_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(self.group_frame, text="每组人数:").pack(side=tk.LEFT, padx=5)
        self.group_size_var = tk.IntVar(value=4)
        group_size_spin = tk.Spinbox(self.group_frame, from_=2, to=10, 
                                     textvariable=self.group_size_var, width=5)
        group_size_spin.pack(side=tk.LEFT, padx=5)
        
        tk.Label(self.group_frame, text="每组出线:").pack(side=tk.LEFT, padx=5)
        self.advance_var = tk.IntVar(value=2)
        advance_spin = tk.Spinbox(self.group_frame, from_=1, to=5, 
                                  textvariable=self.advance_var, width=5)
        advance_spin.pack(side=tk.LEFT, padx=5)
        
        # 最大轮次设置
        max_turns_frame = tk.Frame(settings_frame)
        max_turns_frame.pack(fill=tk.X, pady=5)
        tk.Label(max_turns_frame, text="最大轮次:").pack(side=tk.LEFT, padx=5)
        self.max_turns_var = tk.IntVar(value=2000)
        max_turns_spin = tk.Spinbox(max_turns_frame, from_=100, to=10000, 
                                    textvariable=self.max_turns_var, width=8, increment=100)
        max_turns_spin.pack(side=tk.LEFT, padx=5)
        tk.Label(max_turns_frame, text="(回合数，防止无限循环)").pack(side=tk.LEFT, padx=5)
        
        # 开始比赛按钮
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)
        
        self.start_btn = tk.Button(button_frame, text="开始比赛", 
                                   command=self._start_tournament,
                                   bg="#4CAF50", fg="white", 
                                   font=("Arial", 12, "bold"),
                                   width=15, height=2)
        self.start_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_btn = tk.Button(button_frame, text="停止比赛", 
                                  command=self._stop_tournament,
                                  bg="#f44336", fg="white",
                                  state=tk.DISABLED,
                                  width=15, height=2)
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        # 输出区域
        output_frame = tk.LabelFrame(self.root, text="比赛输出", padx=10, pady=10)
        output_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.output_text = scrolledtext.ScrolledText(output_frame, height=15, 
                                                     wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # 绑定模式变化事件
        self.mode_var.trace('w', self._on_mode_change)
    
    def _on_mode_change(self, *args):
        """比赛模式改变时的处理"""
        mode = self.mode_var.get()
        if mode == "group":
            self.group_frame.pack(fill=tk.X, pady=5)
        else:
            self.group_frame.pack_forget()
    
    def _load_agents(self):
        """加载Agent列表"""
        self.output_text.insert(tk.END, "正在加载参赛者Agent...\n")
        self.root.update()
        
        try:
            loader = AgentLoader(participants_dir="participants")
            self.agents = loader.create_agent_instances()
            
            # 更新列表
            self.agent_listbox.delete(0, tk.END)
            for agent in self.agents:
                self.agent_listbox.insert(tk.END, f"{agent.name} ({agent.__class__.__name__})")
            
            self.output_text.insert(tk.END, f"成功加载 {len(self.agents)} 个Agent\n\n")
        except Exception as e:
            messagebox.showerror("错误", f"加载Agent失败: {e}")
            self.output_text.insert(tk.END, f"加载失败: {e}\n")
        
        self.root.update()
    
    def _log(self, message):
        """输出日志"""
        self.output_text.insert(tk.END, message + "\n")
        self.output_text.see(tk.END)
        self.root.update()
    
    def _start_tournament(self):
        """开始比赛"""
        if len(self.agents) < 2:
            messagebox.showwarning("警告", "至少需要2个Agent才能进行比赛")
            return
        
        # 获取选中的Agent（如果未选中，使用全部）
        selected_indices = self.agent_listbox.curselection()
        if selected_indices:
            selected_agents = [self.agents[i] for i in selected_indices]
        else:
            selected_agents = self.agents
        
        if len(selected_agents) < 2:
            messagebox.showwarning("警告", "至少需要选择2个Agent")
            return
        
        # 禁用开始按钮，启用停止按钮
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        
        # 清空输出
        self.output_text.delete(1.0, tk.END)
        
        # 在新线程中运行比赛
        mode = self.mode_var.get()
        self.tournament_thread = threading.Thread(
            target=self._run_tournament,
            args=(selected_agents, mode),
            daemon=True
        )
        self.tournament_thread.start()
    
    def _run_tournament(self, agents, mode):
        """运行比赛（在后台线程中）"""
        try:
            self._log(f"开始比赛，共 {len(agents)} 个Agent")
            self._log(f"比赛模式: {mode}\n")
            
            max_turns = self.max_turns_var.get()
            self._log(f"最大轮次: {max_turns}\n")
            
            if mode == "group":
                group_size = self.group_size_var.get()
                advance = self.advance_var.get()
                self._log(f"分组设置: 每组 {group_size} 人，每组出线 {advance} 人\n")
                
                tournament = GroupTournament(agents, group_size=group_size, 
                                           advance_per_group=advance,
                                           save_replay=True, replay_dir="replays",
                                           max_turns=max_turns)
                result = tournament.run(verbose=False)
                
                # 输出结果
                self._log("\n" + "="*60)
                self._log("比赛完成！")
                self._log("="*60)
                self._log(f"冠军: {result['champion'].name}")
                self._log(f"小组数: {result['groups']}")
                self._log(f"出线人数: {result['advanced']}\n")
                
                tournament.print_results()
                
            elif mode == "round_robin":
                tournament = RoundRobinTournament(agents, save_replay=True, replay_dir="replays",
                                                 max_turns=max_turns)
                tournament.run(verbose=False)
                self._log("\n比赛完成！回放文件已保存到 replays/ 目录")
                tournament.print_results()
                
            elif mode == "elimination":
                tournament = EliminationTournament(agents, save_replay=True, replay_dir="replays",
                                                  max_turns=max_turns)
                champion = tournament.run(verbose=False)
                self._log(f"\n比赛完成！冠军: {champion.name}")
                self._log("回放文件已保存到 replays/ 目录")
                tournament.print_results()
                
            elif mode == "round_robin_replay":
                # 这个模式已经废弃，因为所有模式都默认支持回放
                tournament = RoundRobinTournament(agents, save_replay=True, replay_dir="replays",
                                                 max_turns=max_turns)
                tournament.run(verbose=False)
                self._log("\n比赛完成！回放文件已保存到 replays/ 目录")
                tournament.print_results()
            
            self._log("\n比赛结束！")
            
        except Exception as e:
            self._log(f"\n错误: {e}")
            import traceback
            self._log(traceback.format_exc())
        finally:
            # 恢复按钮状态
            self.root.after(0, lambda: self.start_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_btn.config(state=tk.DISABLED))
    
    def _stop_tournament(self):
        """停止比赛"""
        # 注意：由于比赛在后台线程运行，这里只能提示
        messagebox.showinfo("提示", "比赛正在运行中，请等待完成")


def main():
    """主函数"""
    root = tk.Tk()
    app = TournamentGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()

